<?php
	$CI = get_instance();
	$CI->load->database();
	$CI->load->dbforge();

	//add column on course table
	$course_fields = array(
	    'is_free_course' => array('type' => 'INT', 'null'  => TRUE, 'constraint' => '11')
	);
	$CI->dbforge->add_column('course', $course_fields);

	//add column on lesson table
	$user_fields = array(
	    'status' => array('type' => 'INT', 'null'  => TRUE, 'constraint' => '11'),
	    'verification_code' => array('type' => 'LONGTEXT', 'null'  => TRUE)
	);
	$CI->dbforge->add_column('users', $user_fields);

	// Make all the user's status 1. Otherwise they won't be able to login.
	$updater = array(
		'status' => 1
	);
	$CI->db->update('users', $updater);

	// insert data on settings table
	$settings_data = array( 'key' => 'protocol', 'value' => 'smtp' );
	$CI->db->insert('settings', $settings_data);

	$settings_data = array( 'key' => 'smtp_host', 'value' => 'ssl://smtp.googlemail.com' );
	$CI->db->insert('settings', $settings_data);

	$settings_data = array( 'key' => 'smtp_port', 'value' => '465' );
	$CI->db->insert('settings', $settings_data);

	$settings_data = array( 'key' => 'smtp_user', 'value' => '' );
	$CI->db->insert('settings', $settings_data);

	$settings_data = array( 'key' => 'smtp_pass', 'value' => '' );
	$CI->db->insert('settings', $settings_data);
?>
